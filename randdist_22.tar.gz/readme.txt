
3/23/2021

This is a prerelease, release of the recreation of the 1700 main street RAND Corporation building.  

This version is just has an impression of the front facade of the original building.

We have conflicting information between my memories,  the blueprints and the pictures.  Where 
possible, I use the pictures as a guide.

There are lots of simplifications and I have taken a very loose approach to lots of architectural
detail.  This will hopefully improve in later versions.  I am interested in what you remember 
or what pictures or other documentation you may have.  I cant promise that I will implement everything
